#!/usr/bin/env python
# encoding: utf-8
"""
 @Time    : 2019/12/10 11:32
 @File    : 123.py
 """

A = []
if A == []:
    print("1")
else:
    print("0")
